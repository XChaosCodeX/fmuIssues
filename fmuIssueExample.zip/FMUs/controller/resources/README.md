# Building the project

By default `gradle` is used as the build system for the Java code.

```
gradle shadowJar
```
