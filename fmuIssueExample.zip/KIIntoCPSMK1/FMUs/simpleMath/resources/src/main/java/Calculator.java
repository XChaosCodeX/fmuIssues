public class Calculator {
   
        public static double lift(double current_time) {
          double speed = 2;
          double real_c = 0;
          double real_cnew = 0;
          double i = 2.3;
            if(current_time<i){
               real_cnew = speed * current_time;
              real_c = real_cnew;
            }else{
              real_c = speed + i;
            }
              
            
            return real_c;
            
      }
      public static double rod(double current_time) {
        double speed = 4;
        double xRodMath = -6;
        double i = 2.2;
          if(current_time > i && current_time < 3 ){
           double time = current_time -i;
            xRodMath = xRodMath + speed * time;
          
          }else{
            
          }
          return xRodMath;
          
    }
    }
        


    

