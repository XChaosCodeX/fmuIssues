import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Model {

    public Double weight = 0.0;
    public Double result = 0.0;
    public Double pressure = 0.0;
    

    private ArrayList<Field> references_to_attributes;

    public Model() throws Exception {

        super();
        this.references_to_attributes = new ArrayList<Field>();
        this.references_to_attributes.add(this.getClass().getField("pressure"));
        this.references_to_attributes.add(this.getClass().getField("weight"));
        this.references_to_attributes.add(this.getClass().getField("result"));
        

    }

    public Fmi2Status fmi2DoStep(double current_time, double step_size, boolean noStepPrior) {
      
       pressure = current_time;
       result = weight + pressure;

      
      
        // update_outputs();
        return Fmi2Status.OK;
    }

    public Fmi2Status fmi2SetReal(Iterable<Integer> references, Iterable<Double> values) throws Exception {

        SetValue(references, values);
        return Fmi2Status.OK;
    }

    public Fmi2Status fmi2SetInteger(Iterable<Integer> references, Iterable<Integer> values) throws Exception {
        SetValue(references, values);
        return Fmi2Status.OK;
    }

    public Fmi2Status fmi2SetBoolean(Iterable<Integer> references, Iterable<Boolean> values) throws Exception {
        SetValue(references, values);
        return Fmi2Status.OK;
    }

    public Fmi2Status fmi2SetString(Iterable<Integer> references, Iterable<String> values) throws Exception {
        SetValue(references, values);
        return Fmi2Status.OK;
    }

    public Fmi2GetValuePair<Double> fmi2GetReal(Iterable<Integer> references) throws Exception {

        ArrayList<Double> values = this.GetValue(references);
        return new Fmi2GetValuePair<Double>(Fmi2Status.OK, values);
    }

    public Fmi2GetValuePair<Integer> fmi2GetInteger(Iterable<Integer> references) throws Exception {
        ArrayList<Integer> values = this.GetValue(references);
        return new Fmi2GetValuePair<Integer>(Fmi2Status.OK, values);
    }

    public Fmi2GetValuePair<Boolean> fmi2GetBoolean(Iterable<Integer> references) throws Exception {
        ArrayList<Boolean> values = this.GetValue(references);
        return new Fmi2GetValuePair<Boolean>(Fmi2Status.OK, values);
    }

    public Fmi2GetValuePair<String> fmi2GetString(Iterable<Integer> references) throws Exception {
        ArrayList<String> values = this.GetValue(references);
        return new Fmi2GetValuePair<String>(Fmi2Status.OK, values);
    }

    public Fmi2Status fmi2EnterInitializationMode() {
        return Fmi2Status.OK;
    }

    public Fmi2Status fmi2ExitInitializationMode() {
        update_outputs();
        return Fmi2Status.OK;
    }

    public Fmi2Status fmi2SetupExperiment(double start_time, Double stop_time, Double tolerance) {
        return Fmi2Status.OK;
    }

    public Fmi2Status fmi2Reset() {
        this.pressure = 0.0;
        this.weight = 0.0;
        this.result = 0.0;
       
        return Fmi2Status.OK;
    }

    public Fmi2Status fmi2Terminate() {
        return Fmi2Status.OK;
    }

    public Fmi2Status fmi2CancelStep() {
        return Fmi2Status.OK;
    }

    public Fmi2SerializePair fmi2ExtSerialize() throws Exception {

        var b = new ByteArrayOutputStream();
        var o = new ObjectOutputStream(b);

        o.writeObject(this);

        return new Fmi2SerializePair(Fmi2Status.OK, b.toByteArray());
    }

    public Fmi2Status fmi2ExtDeserialize(byte[] bytes) throws Exception {

        try (ByteArrayInputStream b = new ByteArrayInputStream(bytes)) {
            try (ObjectInputStream o = new ObjectInputStream(b)) {
                var other = (Model) o.readObject();
                this.pressure = other.pressure;
                this.weight = other.weight;
                this.result= other.result;
                
            }
        }

        return Fmi2Status.OK;
    }

    private <T> ArrayList<T> GetValue(Iterable<Integer> references) throws Exception {
        var values = new ArrayList<T>();

        for (var ref : references) {

            @SuppressWarnings("unchecked")
            var val = (T) this.references_to_attributes.get(ref).get(this);
            values.add(val);
        }

        return values;

    }

    private <T> void SetValue(Iterable<Integer> references, Iterable<T> values) throws Exception {

        Iterator<Integer> i1 = references.iterator();
        Iterator<T> i2 = values.iterator();
        while (i1.hasNext() && i2.hasNext()) {
            this.references_to_attributes.get(i1.next()).set(this, i2.next());
        }
    }

    private void update_outputs() {
       

    }

    class Fmi2GetValuePair<T> {
        Fmi2Status status;
        List<T> values;

        Fmi2GetValuePair(Fmi2Status status, List<T> values)

        {
            this.status = status;
            this.values = values;
        }
    }

    class Fmi2SerializePair {
        public Fmi2Status status;
        public byte[] bytes;

        Fmi2SerializePair(Fmi2Status status, byte[] bytes) {
            this.status = status;
            this.bytes = bytes;
        }
    }

    enum Fmi2Status {
        OK,
        Warning,
        Discard,
        Error,
        Fatal,
        Pending
    }

}
